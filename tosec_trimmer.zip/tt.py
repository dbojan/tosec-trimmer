
#2023-09-29-1

#set make_m3u_playlist=1, to create m3u playlist, for retroarch
make_m3u_playlist=0
playlistext='.m3u'

renamed_folder_suffix='-sorted'

#for htm or html windows will connect folders with htm(l) files, automatically moving _files folder
#use ren *.htm *.m3u to change back to m3u, after copying or moving playlist (and folder automatically)
#playlistext='.htm'

#files_connect='_files'
#if you do not wish to use '_files' set it to empty var: 
files_connect=''

use_numbers_for_disks=0
#use_numbers_for_disks=0# use 'game name disk_a', 'game name disk_b', (hatari emulator auto inserts disk_b), default
#use_numbers_for_disks=1# use 'game name disk_1','game name_disk 2'
#use_numbers_for_disks=2# use 'game name(disk 1 of 2)'
#use_numbers_for_disks=3# use 'game name(disk 1 of 2)[more tags here], original name of zip files'. The path might be to long, you will get error:   File "I:\Desktop\tosec_trimmer\tt.py", line 161, in fCreateFiles
#sometimes might show error if the file path is longer than 260 characters
#use setting other than 3, or move original folder closer to root of the hard disk, for example to d:\tos-games instead of d:\games\atari st\tosec....


import sys
import os
import re
import time
import pathlib
import shutil
import tempfile

start_time = time.time()



try:
	indir=sys.argv[1]
	print('Input dir:',indir)
except:
	print('Please pass directory name')
	exit()
	
	
if not os.path.isdir(indir):
	print('Please pass *existing* directory name')
	exit()



r'''
indir = "d:/Amiga - Games - test2"

indir = r'I:\ROMS_HC\roms all\TOSEC_V2017-04-23\Commodore Amiga - Games - [ADF] (TOSEC-v2017-04-12_CM)'
#indir = r'I:\ROMS_HC\roms all\TOSEC_V2017-04-23\Commodore Amiga - Games - Emerald Mine (TOSEC-v2016-12-19_CM)'
#indir = r'I:\ROMS_HC\roms all\TOSEC_V2017-04-23\Commodore Amiga - Games - Public Domain - [ADF] (TOSEC-v2017-04-22_CM)'
indir = r'I:\ROMS_HC\roms all\TOSEC_V2017-04-23\Atari ST - Games - [ST] (TOSEC-v2015-05-07_CM)'
#indir = r'I:\ROMS_HC\roms all\TOSEC_V2017-04-23\Atari ST - Games - [STX] (TOSEC-v2015-05-07_CM)'
#indir = 'i:/test'
indir = r'C:\temp\Atari ST - Games - [STX] (TOSEC-v2015-05-07_CM)'
indir = r'C:\stx'
indir = r'd:\st'
'''

outdir = indir+renamed_folder_suffix
#outdir = pathlib.Path(indir).drive+'/'+pathlib.PurePath(indir).name+'-sorted'
#outdir = pathlib.Path(indir).drive+'/'+'atari stx - tosec '+'-sorted'

print('Output dir:',outdir)
if os.path.isdir(outdir):
	print('Output dir exists, exiting!')
	exit()





def fMakeHardlink(source,dest):
	if not os.path.isfile(dest):
		if os.path.isfile(source):
			os.link(source,dest)


def fCheckFolder(destfolder):
	if not os.path.exists(destfolder):
		os.makedirs(destfolder)


#fRemoveDuplicates(value,listnow_justname,listnow_fullname,listnow_justname_lower)
def fRemoveDuplicates(value,listnow_justname,listnow_fullname,listnow_justname_lower):
	for v in value:#Beneath a Steel Sky v1.0 (1994-03-10)(Virgin)(Disk 02 of 15)(0)[tag]
		split_before_square_tag = v.split('[',1)[0]#'Beneath a Steel Sky v1.0 (1994-03-10)(Virgin)(Disk 02 of 15)(0)'
		#sometimes, for multidisk games, there are things after '(Disk x of x)', but before [, such as '(0)' or 'boot'.
		#remove things after (Disk x of x), but before [], cause it will create problems later
		#use this cleaned text as dictionary key
		#print ('before disk:' ,split_before_square_tag)
		if "(Disk " in split_before_square_tag:#"Beneath a Steel Sky v1.0 (1994-03-10)(Virgin)(Disk 02 of 15)(0)"
			split_before_disk = split_before_square_tag.split("(Disk ",1)[0]#"Beneath a Steel Sky v1.0 (1994-03-10)(Virgin)"
			disk_open = "(Disk "
			split_after_disk = split_before_square_tag.split("(Disk ",1)[1]#"02 of 15)(0)"
			split_after_disk_no_closing_bracket = split_after_disk.split(")",1)[0]#"02 of 15
			closing_bracket = ")"
			split_with_disk_only = split_before_disk + disk_open + split_after_disk_no_closing_bracket + closing_bracket
			split_before_square_tag = split_with_disk_only
			#print ("with disk:" ,split_before_square_tag)
		#add to dict, if they key does not exist in dict.
		#print("before adding, whole dict:", dictnow)
		split_before_square_tag = split_before_square_tag.rsplit(".zip", 1)[0]#remove extension if exist, because it will be removed when splitting [ , to avoid adding both with and without extension
		#cannot split "." because of v1.0
		#print ("after removing extension",splitv0)
		if split_before_square_tag.lower() not in listnow_justname_lower:#use listnow_justname_lower to check if lowercase in list justname, if not add to justname, and justnamelower, add full name with zip to fullname
			#print('added:',split_before_square_tag)
			listnow_justname.append( split_before_square_tag )
			listnow_fullname.append(v)
			listnow_justname_lower.append( split_before_square_tag.lower() )


		
#def fCreateFiles(dictnow,typeofcat,indir,outdir,listnow_lower):
def fCreateFiles(listnow_justname, listnow_fullname,typeofcat,indir,outdir,listnow_lower):
	output_folder_with_category = outdir +'/'+ typeofcat
	fCheckFolder(output_folder_with_category)
#	for key,value in sorted(dictnow.items()):
	for listnow_justname_item,listnow_fullname_item in zip(listnow_justname, listnow_fullname):
		disk_without_leading_zero='(Disk 1 of '
		disk_with_leading_zero='(Disk 01 of '
		if not '(Disk ' in listnow_justname_item:
			fMakeHardlink(indir+'/'+listnow_fullname_item  ,    output_folder_with_category +'/'+ listnow_fullname_item)#listnow_fullname_item is actual name of disk
			if make_m3u_playlist == 1:
				with open(   ( output_folder_with_category +'/'+ listnow_fullname_item  ).rsplit('.',1)[0]+playlistext, "w") as playlist: #remove .zip for playlist name #rsplit on . max one time, and use left part
					playlist.write(listnow_fullname_item)
			
		#it has '(disk ) in name so it is multidisk game
		elif disk_without_leading_zero in listnow_justname_item or disk_with_leading_zero in listnow_justname_item:#Beneath a Steel Sky v1.0 (1993-03-10)(Virgin)(Disk 1 of 15)
			if disk_without_leading_zero in listnow_justname_item: #disk 1 of
				split_listnow_justname_item_by_disk_part = listnow_justname_item.split(disk_without_leading_zero,1)#'Beneath a Steel Sky v1.0 (1993-03-10)(Virgin)',         '15)'
			elif disk_with_leading_zero in listnow_justname_item: #disk 01 of
				split_listnow_justname_item_by_disk_part = listnow_justname_item.split(disk_with_leading_zero,1)#'Beneath a Steel Sky v1.0 (1993-03-10)(Virgin)',         '15)'
			

			second_part_split_by_bracket = split_listnow_justname_item_by_disk_part[1].split(')',1)#'15'
			last_number = second_part_split_by_bracket[0]#'5', same as above with[0]

			#for catching '5', in 'game disk 1 of 5'. The line for catching '5' in 'game name disk 2 of 5' is further below.
			#error if 'game disk 1 of f' instead of 'game disk 1 of 5'
			if not last_number.isnumeric():
				print('*** Error, last number is not a number!!! It is:', last_number, ', Game set not created for:', listnow_justname_item, '***' )
				continue #continue instead of break, to continue with next alphabetical game file(s) in folder, thanks /u/rockstarfruitpunch
	
			destination_link_game_folder_name_with_total_disks = split_listnow_justname_item_by_disk_part[0]+'(Disks '+ last_number +')' + files_connect #'Beneath a Steel Sky v1.0 (1993-03-10)(Virgin)(Disks 15)'
			fCheckFolder( output_folder_with_category +'/'+  destination_link_game_folder_name_with_total_disks)#make folder			

				
			#add leading zero if needed, for disk number
			listfiles = []
			for ivar in range(1,int(last_number)+1):
				if int(last_number) > 9 and ivar < 10: #1 vs 01
					leading_zero = '0'
				else:
					leading_zero = ''

				

				if int(last_number) > 26 or use_numbers_for_disks > 0:#if==1 use name of the game_1, _2, if==2 use name of the game (disk 1 of 2) see below
					if int(last_number) > 26: print('lots of disks:',listnow_fullname_item)#just in case there are more than 26 letters, use numbers
					character_letter = str(ivar)
				else:#if ==0 use xx_diska, disk b
					#convert number to letter for disk number
					starting_point = 96
					character_letter = chr(starting_point+ivar)#convert disk1 to diska, but no more than 26, else use numbers

				#have to calculate because of all multidisks, cannot use just listnow_fullname_item. also, it cleaned/normalized before in code
				source_justname = split_listnow_justname_item_by_disk_part[0]+'(Disk '+leading_zero+str(ivar)+' of '+last_number+')'
				if source_justname.lower() in listnow_lower:#check for disk 1 to last number
					#x = fruits.index("cherry") 
					index_of_found_item_in_listnow_lower = listnow_lower.index(source_justname.lower() ) #in case it exists in the list of files, but with different case: lower or uppercase
					source_fullname = listnow_fullname[index_of_found_item_in_listnow_lower]#we use real, long name with zip
				else:
					print('*** Warning: missing disk:', source_justname, '***')
					continue #no second or third or ... disk, skip disk creating this round
				
				#add _b.zip
				#remove _files from file_diska name
				destination_game_disk_filename_link = destination_link_game_folder_name_with_total_disks.replace(files_connect,'')  +'_'+   character_letter+'.zip'
				if use_numbers_for_disks == 2:
					destination_game_disk_filename_link = source_justname+'.zip'#use made name, remove all after (disk x of y)
				if use_numbers_for_disks == 3:#warning path might be to long
					destination_game_disk_filename_link = source_fullname

				if len(output_folder_with_category +'/'+  destination_game_disk_filename_link) > 255:
					print ('more than 255, using numbers for disks:', output_folder_with_category +'/'+  destination_game_disk_filename_link )
					
				#print('creating link indir:', indir)
				#print('source filename:', source_fullname)
				#print('dest name:',destination_game_disk_filename_link)
				#print('creating link outdir:', output_folder_with_category +'/'+    destination_link_game_folder_name_with_total_disks  )
				fMakeHardlink(indir+'/'+ source_fullname ,   output_folder_with_category +'/'+    destination_link_game_folder_name_with_total_disks  + '/' +  destination_game_disk_filename_link)
				listfiles.append( destination_link_game_folder_name_with_total_disks + '/'   + destination_game_disk_filename_link)
					
			if listfiles and make_m3u_playlist == 1:
				#without_files_connect here, cause it is the name of the playlist
				#remove _files from file_diska name
				with open( output_folder_with_category +'/'+  destination_link_game_folder_name_with_total_disks.replace(files_connect,'') + playlistext   , "w") as playlist:
					playlist.write("\n".join(listfiles))
	#print(outdir+typeofcat+'md')
	#input()
	
		

#create list of files sorted:

dir1 = os.listdir(indir)
dir1.sort

#dir1 = tuple(  sorted( os.listdir(indir)  )   )#faster?

#add to tagged lists:
listbad = {
#each file can have one tag here, so get bad tags first
#bad, leading_column=_a3bad_
#[a baddump]
#\[a[\s\]\d]baddump\]. [a10 baddump]?
#[baddump] ? \[*baddump*\] , not originally bad dump, but modified in some way, I think.

  "bad_otherbaddump": (r'\[*baddump*\]', '_800000_otherbaddump_'), 
  "bad_baddump": (r'\[b[\s\]\d]', '_810000_baddump_'), 
  "bad_virvs": (r'\[v[\s\]\d]', '_820000_virvs_'), 
}

listok = {
#oh no. first check this one in group of goods. so we can tag it as copy protected
  "ok_copyprotected": (r'\[u[\s\]\d]', '_710000_copyprotected_'),
#sometimes does not work  
  "ok_underdump": (r'\[u[\s\]\d]', '_510000_underdump_'), 
  
#usually works
  "ok_overdump": (r'\[o[\s\]\d]', '_430000_overdump_'), 
# others that are ok:
  "ok_notitlescreen": (r'\[no title screen[\s\]\d]', '_420000_notitlescreen_'), 
 
  "ok_alternate": (r'\[a[\s\]\d]', '_400000_alternate_'),#usualy has more tags. [a baddump]?
  
  
  #Rick Dangerous (1989)(Core Design - Firebird)[cr HRFH - Revolution]
  
  "ok_crackedHRFH": (r'\[cr HRFH - Revolution\]', '_130050_crackedHRFH_'), #cannot pass intro?
 
 "ok_cracked": (r'\[cr[\s\]\d]', '_130000_cracked_'), #don't really care if it is ... :)
 
  "ok_goodrom": (r'\[\![\s\]\d]', '_120000_goodrom_'), #[!
  "ok_notagregex": (r'^[^\[]+$', '_100000_notagregex_'), #not[ in string
  
  
  #'[! ' , group after !, could be space, ], or number. could also have other tags such as [m], so not 100000
 
 }
 
  
 #none of the above, has to be last, before the language tags
noneoftheabove ='_110000_noneoftheabove_' #none of the above
 
#foreign languages
#set label for 'it has foreign tag'
#100 is liked more than 110..., so it will be left with the more liked, if it has manu lang tags

#[\(\-]fr[\-\)]
#when looking for 'fr' language it can be: 
#(fr-es) or (de-fr),       on the left '-'  or '('  before 'fr' ;        and  on the right '-' or ')' after 'fr'
#"lang_jp": ('\(jp\)', '_140jp_'),  previous version

listforeign = {
 "lang_jp": (r'[\(\-]jp[\-\)]', '_140jp_'),  
 "lang_de": (r'[\(\-]de[\-\)]', '_130de_'),  
 "lang_es": (r'[\(\-]es[\-\)]', '_120es_'), 
 "lang_it": (r'[\(\-]it[\-\)]', '_110it_'), 
 "lang_fr": (r'[\(\-]fr[\-\)]', '_100fr_'), 
}

#but not if it also contains english
lang_en = r'[\(\-]en[\-\)]'



#SORT THEM INTO CATEGORIES, AND WITHIN CATEGORIES SORT THEM BY THE SCORE
#define empty dictionary
dictag = {}
for f in dir1:#iterate over lines
	#undefined until cat=''. After cat='', defined, but does not exist ... if not cat: ...  gives ok
	langfile=''
	leading_column=''
	cat=''
	#print ('start====',f)
	#for each line iterate over keys in dk
	nowlist=listbad
	for dk in nowlist: #dk now has first value from dict for example 'ok-cracked' #(
		#print('dk:',  dk, nowlist[dk][0]       );input()
		if re.search(nowlist[dk][0], f, re.IGNORECASE):
			if not cat:
				cat=nowlist[dk][1] # nowlist[dk][1] holds value '_800000_baddump_'
				leading_column='_3bad_' #switch value of leading column from "_a1ok_"
				#print('inside bad-',leading_column,cat,f,) ;input()
	
	nowlist=listok
	for dk in nowlist: #dk now has first value from dict for example 'ok-cracked' #(
		#print('dk:',  dk, nowlist[dk][0]       );input()
		if re.search(nowlist[dk][0], f, re.IGNORECASE):
			if not cat:
				#if dk == 'ok_notagregex' :
					#print(nowlist[dk][0],dk,'notag',f)			
				cat=nowlist[dk][1] # nowlist[dk][1] holds value '_800000_baddump_'
				leading_column='_1ok_' 
				#print('inside bad-',leading_column,cat,f,) ;input()
	
	if not cat:	
		cat=noneoftheabove    #nowlist['noneoftheabove'][1]
		leading_column='_1ok_'
		#print('inside noneoftheaboves-',leading_column,cat,f,) ;input()
			
			
	nowlist=listforeign
	for dk in nowlist: #dk now has first value from dict for example 'ok-cracked' #(				
		if re.search(nowlist[dk][0], f, re.IGNORECASE) and not re.search(lang_en, f, re.IGNORECASE):	
			#langfile is otherwise not printed, it does not exist, it is blank when printed. 
			#now leading column becoms 3foreign, and second column becomes fr, moving cat to the third column
			#print('inside lang****',dk,'ok-',f) ;input()
			langfile=nowlist[dk][1]
			leading_column='_2foreign_'
			#print('inside language-',leading_column,langfile,cat,f,) ;input()
	
	#)	
	#print('end+++',leading_column,langfile,cat,f) #;input()
	
	#add set key in dictionary to "'a'+leading_column+langfile+cat'" if it does not exist, and append value,  to that of before values
	#have to use setdefault otherwise complains about key not existing, and can't set it to '' cause it would delete each value from before
	dictag.setdefault(leading_column+langfile+cat,[] ).append(f) #leading_column+langfile+cat + '  ' + f; you append values to to []




#REMOVE DUPLICATES WITHIN CATEGORIES, USING SCORE AS PRIORITY WHICH FILE TO INCLUDE FIRST
#resulting cats with be in the following dicts: dictcat[   'name before ['   ] = name whole


listok_justname = []
listfor_justname = []
listbad_justname = []

listok_fullname = []
listfor_fullname = []
listbad_fullname = []

listok_justname_lower = []
listfor_justname_lower = []
listbad_justname_lower = []


#print('just one cat: ', dictag['_1ok__130000_cracked_'],'\n')
#input()

#has to be sorted, 800000 comes before 810000
#for key,value in [x for x in dictag.items() if "_a3bad_" in x]
#also 1ok comes before 3 bad
#for key,value in dictag.items():
#still not sorted by game name, just by 10000, 110000
#in key:  _1ok__100000_notagregex_ in value: ["'Nam 1965-1975 (1991)(Domark)(M4).zip", '1943 - The Battle of Midway (1988)(Go!).zip', '...
for key,value in sorted(dictag.items()):
	#print('in key: ',key, 'in value:',value)
	if '_1ok_' in key:#for 'ok' list
		fRemoveDuplicates(value,listok_justname,listok_fullname,listok_justname_lower)

	if '_2foreign_' in key:
		fRemoveDuplicates(value,listfor_justname,listfor_fullname,listfor_justname_lower)

				
	if '_3bad_' in key:
		#print ('\n',key)
		fRemoveDuplicates(value,listbad_justname,listbad_fullname,listbad_justname_lower)


'''
print('ok justname',listok_justname )
print('ok fullname', listok_fullname )
print('ok lower', listok_justname_lower )
print('lengths',len(listok_justname), len(listok_fullname), len(listok_justname_lower) )


print('for justname',listfor_justname )
print('for fullname', listfor_fullname )
print('for lower', listfor_justname_lower )
print('lengths',len(listfor_justname), len(listfor_fullname), len(listfor_justname_lower) )


print('bad justname',listbad_justname )
print('bad fullname', listbad_fullname )
print('bad lower', listbad_justname_lower )
print('lengths',len(listbad_justname), len(listbad_fullname), len(listbad_justname_lower) )
'''

#list1, list2 = zip(*sorted(zip(list1, list2)))


#dictok = {}
#dictfor = {}
#dictbad = {}

#sort each cat together all 3 lists, (you ll get tuples)
##create dicts
if listok_justname and listok_fullname and listok_justname_lower:
	listok_justname, listok_fullname, listok_justname_lower = zip(*sorted(zip(listok_justname, listok_fullname, listok_justname_lower)))
	#dictok = dict(zip(listok_justname, listok_fullname))

if listfor_justname and listfor_fullname and listfor_justname_lower:
	listfor_justname, listfor_fullname, listfor_justname_lower = zip(*sorted(zip(listfor_justname, listfor_fullname, listfor_justname_lower)))
	#dictfor = dict(zip(listfor_justname, listfor_fullname))
	
if listbad_justname and listbad_fullname and listbad_justname_lower:
	listbad_justname, listbad_fullname, listbad_justname_lower = zip(*sorted(zip(listbad_justname, listbad_fullname, listbad_justname_lower)))
	#dictbad = dict(zip(listbad_justname, listbad_fullname))




'''
print('ok :',len(dictok),dictok)		
print('ok lower',len(listok_justname_lower),listok_justname_lower)	
print('for :',len(dictfor),dictfor)	
print('for lower',len(listfor_justname_lower),listfor_justname_lower)	
print('bad :',len(dictbad),dictbad)	
print('bad lower',len(listbad_justname_lower),listbad_justname_lower)	
#input()
#exit()
'''

#COPY / MK CREATING OF FILES
if not os.path.exists(outdir):
    os.makedirs(outdir)

fCreateFiles(listok_justname, listok_fullname,'1ok',indir,outdir,listok_justname_lower)
fCreateFiles(listfor_justname, listfor_fullname,'2foreign',indir,outdir,listfor_justname_lower)
fCreateFiles(listbad_justname, listbad_fullname,'3bad',indir,outdir,listbad_justname_lower)

print ('Sorted and cleared hardlink files in:', outdir)
print("--- %.2f seconds ---" % (time.time() - start_time))

	

#go over group of tagged list and remove duplicates
#compare foreign and bad with good
#go over the list, if they exist on hdd copy single files to destination , named after list. 
#check if they have 'disk 1 of ', or 'disk 01 of "
#if they do find number of the last disk
#check if 2-last exist in dirlist
#(optional unzip them to temp folder, and zip them together)
#if they do copy them to (1-last) destination folder, named after list. 

